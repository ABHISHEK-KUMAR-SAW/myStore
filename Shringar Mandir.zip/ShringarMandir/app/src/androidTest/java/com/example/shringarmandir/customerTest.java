package com.example.shringarmandir;

import android.view.View;

import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;


import static org.junit.Assert.*;

public class customerTest {

    @Rule
    public ActivityTestRule<customer> activityTestRule = new ActivityTestRule<customer>(customer.class);   //enables launching the activity

    private customer myActivity = null;

    @Before
    public void setUp() throws Exception {    //called every time we execute a test
        myActivity = activityTestRule.getActivity();
    }

    @Test
    public void whileLaunching(){    // befor whileLaunching(), setUp() will be executed and after whileLaunching(), tearDown()
        View view = myActivity.findViewById(R.id.drawer);
        assertNotNull(view);
    }

    @After
    public void tearDown() throws Exception {  // called every time after executing the test case. We will do clean up here
        myActivity = null;
    }
}