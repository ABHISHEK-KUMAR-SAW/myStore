package com.example.shringarmandir;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ActionMenuView;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.SearchView;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class place_order extends Fragment {

    MenuItem searchbar;
    RecyclerView items;
    Menu menu;
    place_order_adapter adapter;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference reference = database.getReference();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_place_order, container, false);

        FirebaseRecyclerOptions<item_variables> items_order =
                new FirebaseRecyclerOptions.Builder<item_variables>()
                        .setQuery(reference.child("Items"), item_variables.class)
                        .build();

        items = view.findViewById(R.id.recView);
        items.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new place_order_adapter(items_order);
        items.setAdapter(adapter);
        //setHasOptionsMenu(true); //require to change visibility of toolbar menu item
        return view;
    }

    /*public void onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.search);
        item.setVisible(true);
        SearchView searchView = (SearchView) item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                searchInProgress(s);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                searchInProgress(s);
                return true;
            }
        });
    }

    private void searchInProgress(String s){
        FirebaseRecyclerOptions<item_variables> items_order =
                new FirebaseRecyclerOptions.Builder<item_variables>()
                        .setQuery(reference.child("Items").orderByChild("name").startAt(s).endAt(s+"\uf8ff"), item_variables.class)
                        .build();

        adapter = new place_order_adapter(items_order);
        adapter.startListening();
        items.setAdapter(adapter);
    }*/

    @Override
    public void onStart(){
        super.onStart();
        adapter.startListening();
    }

    public void onStop(){
        super.onStop();
        adapter.stopListening();
    }
}