package com.example.shringarmandir;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ConcurrentModificationException;

public class cart_adapter extends FirebaseRecyclerAdapter<item_variables,cart_adapter.viewHolder> {

    Context context;
    ViewGroup viewGroup;
    View view;
    TextView total;
    int sumTotal = 0;
    public cart_adapter(@NonNull FirebaseRecyclerOptions<item_variables> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull viewHolder holder, final int position, @NonNull final item_variables model) {
        holder.name.setText(model.getName());
        holder.price.setText(model.getPrice());
        holder.image.setImageResource(R.drawable.account_img);

        holder.remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder adb = new AlertDialog.Builder(context);
                adb.setMessage("Do you really want to remove this item from cart ?");
                adb.setTitle("Confirm");
                adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(context,"Item removed from cart",Toast.LENGTH_SHORT).show();
                        FirebaseDatabase.getInstance().getReference().child("orders")
                                .child(getRef(position).getKey()).removeValue();

                        Toast.makeText(context,"Item removed from cart",Toast.LENGTH_SHORT).show();
                    }
                });
                adb.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                adb.show();
            }
        });
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_order_layout,parent,false);
        ImageButton im = v.findViewById(R.id.add);
        context = parent.getContext();
        viewGroup = parent;
        Drawable d = context.getDrawable(R.drawable.remove_circular);
        im.setBackground(d);

        return new viewHolder(v);
    }

    class viewHolder extends RecyclerView.ViewHolder {

        TextView name, price;
        ImageView image;
        ImageButton remove;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.itemImage);
            name = itemView.findViewById(R.id.itemName);
            price = itemView.findViewById(R.id.itemPrice);
            remove = itemView.findViewById(R.id.add);
        }
    }

}
