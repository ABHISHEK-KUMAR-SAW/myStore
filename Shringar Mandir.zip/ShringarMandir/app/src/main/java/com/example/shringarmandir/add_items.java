package com.example.shringarmandir;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class add_items extends Fragment {

    EditText item_name,item_price;
    Button add;
    FirebaseDatabase database;
    DatabaseReference reference;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_items, container, false);
        item_name = view.findViewById(R.id.name);
        item_price = view.findViewById(R.id.price);
        add = view.findViewById(R.id.btn);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Items");
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_it();
            }
        });
        return view;
    }

    public void add_it(){
        String name = item_name.getText().toString();
        String price = item_price.getText().toString();
        HashMap<String,String> hm = new HashMap<>();
        hm.put("name",name);
        hm.put("price",price);
        reference.push().setValue(hm);
        item_name.setText("");
        item_price.setText("");
        Toast.makeText(getContext(),"Item Added Successfully",Toast.LENGTH_SHORT).show();
    }
}