package com.example.shringarmandir;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class fragment_adapter extends FragmentPagerAdapter {
    @NonNull

    private int tab_no;

    public fragment_adapter(@NonNull FragmentManager fm, int behavior, int tab_no) {
        super(fm, behavior);
        this.tab_no = tab_no;
    }


    public Fragment getItem(int position) {
        switch (position)
        {
            case 0: return new pending_orders();
            case 1: return new packed_orders();
            case 2: return new completed_orders();
            default: return null;
        }
    }

    @Override
    public int getCount() {
        return tab_no;
    }
}
