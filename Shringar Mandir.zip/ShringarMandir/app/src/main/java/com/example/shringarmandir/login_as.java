package com.example.shringarmandir;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class login_as extends AppCompatActivity {
    EditText userid, password;
    RadioGroup radioGroup;
    String loginType = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_as);
        userid = findViewById(R.id.user);
        password = findViewById(R.id.password);
        radioGroup = findViewById(R.id.radio);
    }

    public void login(View v){
        String user = userid.getText().toString();
        String pass = password.getText().toString();
        if(user.isEmpty()) {
            userid.setError("Field is required!");
            userid.setHint("Please enter User Id");
        }
        else if(pass.isEmpty()) {
            password.setError("Field is required!");
            password.setHint("Please enter Password");
        }
        else if(radioGroup.getCheckedRadioButtonId()==-1){
            Toast.makeText(this,"Please choose the login type as customer or retailer",Toast.LENGTH_SHORT).show();
        }
        else{
            RadioButton rb = findViewById(radioGroup.getCheckedRadioButtonId());
            String type = rb.getText().toString();
            loginType = type;
            if(type.equals("Retailer")) {
                if(!user.equals("user") || !pass.equals("password"))
                    Toast.makeText(this,"Please enter valid Retailer User Id or Password",Toast.LENGTH_SHORT).show();
                else{
                    Intent i = new Intent(this, shopkeeper.class);
                    startActivity(i);
                    Toast.makeText(this,"Welcome Retailer",Toast.LENGTH_SHORT).show();
                }
            }
            else {
                userDatabase db = new userDatabase(getApplicationContext());
                boolean valid = db.validUser(userid.getText().toString());
                if(valid){
                    String getPass = db.getPassword(userid.getText().toString());
                    if(getPass.equals(password.getText().toString())){
                        Intent i = new Intent(this,customer.class);
                        startActivity(i);
                        Toast.makeText(this,"Welcome Customer",Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(this,"Please enter valid password",Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(this,"Customer does not exist",Toast.LENGTH_SHORT).show();
            }
        }

    }

    public void register(View v)
    {
        Intent i = new Intent(this,register.class);
        startActivity(i);
    }

    public String getLoginType(){
        return loginType;
    }
}