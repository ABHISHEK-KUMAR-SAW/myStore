package com.example.shringarmandir;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;


public class completed_orders extends Fragment {

    RecyclerView completed;
    completed_adapter adapter;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_completed_orders, container, false);
        completed = v.findViewById(R.id.completed);
        completed.setLayoutManager(new LinearLayoutManager(getContext()));
        FirebaseDatabase.getInstance().getReference("completed_orders").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<String> al = new ArrayList<>();
                ArrayList<ArrayList<String>> data = new ArrayList<>();
                for(DataSnapshot ds:snapshot.getChildren()) {
                    al.add(ds.getKey().toString());
                    ArrayList<String> temp = new ArrayList<>();
                    for(DataSnapshot child:ds.getChildren()){
                        Map<String,String> item = (Map<String, String>) child.getValue();
                        temp.add(item.get("name")+" - Rs. "+item.get("price"));
                    }
                    data.add(temp);
                }
                adapter = new completed_adapter(al,data);
                completed.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return v;
    }
}