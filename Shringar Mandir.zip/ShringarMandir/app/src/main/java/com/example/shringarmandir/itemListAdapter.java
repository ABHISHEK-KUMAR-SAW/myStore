package com.example.shringarmandir;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class itemListAdapter extends FirebaseRecyclerAdapter<item_variables,itemListAdapter.viewHolder>{

    Context context;

    public itemListAdapter(@NonNull FirebaseRecyclerOptions<item_variables> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final viewHolder holder, final int position, @NonNull final item_variables model) {
        holder.name.setText(model.getName());
        holder.price.setText(model.getPrice());
        holder.image.setImageResource(R.drawable.account_img);

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder adb = new AlertDialog.Builder(context);
                LayoutInflater li = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View v = li.inflate(R.layout.edit_layout,null);
                final EditText name = v.findViewById(R.id.name);
                final EditText price = v.findViewById(R.id.price);
                name.setText(model.getName());
                price.setText(model.getPrice());
                adb.setView(v);
                adb.setTitle("Updating Item Details");
                adb.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String new_name = name.getText().toString();
                        String new_price = price.getText().toString();
                        Map<String,Object> new_data = new HashMap<>();
                        new_data.put("name",new_name);
                        new_data.put("price",new_price);
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference reference = database.getReference();
                        reference.child("Items").child(getRef(position).getKey()).updateChildren(new_data)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Toast.makeText(context,"Updation Successfull",Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(context,"Please Try Again!",Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                });

                adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(context,"Updation Cancelled",Toast.LENGTH_SHORT).show();
                    }
                });

                adb.show();
            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder adb = new AlertDialog.Builder(context);
                adb.setMessage("Do you really want to delete this item ?");
                adb.setTitle("Confirm");
                adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        FirebaseDatabase.getInstance().getReference().child("Items")
                                .child(getRef(position).getKey()).removeValue();
                        Toast.makeText(context,"Item Deleted Successfully",Toast.LENGTH_SHORT).show();
                    }
                });
                adb.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                adb.show();
            }
        });
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_layout,parent,false);
        context = parent.getContext();
        return new viewHolder(view);
    }

    class viewHolder extends RecyclerView.ViewHolder{
        TextView name, price;
        ImageView image;
        Button edit;
        ImageButton delete;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.itemImage);
            name = itemView.findViewById(R.id.itemName);
            price = itemView.findViewById(R.id.itemPrice);
            edit = itemView.findViewById(R.id.edit);
            delete = itemView.findViewById(R.id.delete);
        }
    }
}
