package com.example.shringarmandir;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;


public class packed_orders extends Fragment {

    RecyclerView packed;
    packed_adapter adapter;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final String loginType = getActivity().getClass().getSimpleName();

        View v = inflater.inflate(R.layout.fragment_packed_orders, container, false);
        packed = v.findViewById(R.id.packed);
        packed.setLayoutManager(new LinearLayoutManager(getContext()));

        FirebaseDatabase.getInstance().getReference("packed_orders").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<String> al = new ArrayList<>();
                ArrayList<ArrayList<String>> data = new ArrayList<>();
                for(DataSnapshot ds:snapshot.getChildren()) {
                    al.add(ds.getKey().toString());
                    ArrayList<String> temp = new ArrayList<>();
                    for(DataSnapshot child:ds.getChildren()){
                        Map<String,String> item = (Map<String, String>) child.getValue();
                        temp.add(item.get("name")+" - Rs. "+item.get("price"));
                    }
                    data.add(temp);
                }
                adapter = new packed_adapter(al,data,loginType);
                packed.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return v;
    }

    public void onPause(){
        super.onPause();
        FirebaseDatabase.getInstance().getReference().child("completed_orders").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<String> items = new ArrayList<>();
                for(DataSnapshot ds:snapshot.getChildren())
                    items.add(ds.getKey().toString());
                remove_from_placed(items);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void remove_from_placed(ArrayList<String> items){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        for(int i=0;i<items.size();i++){
            ref.child("packed_orders").child(items.get(i)).removeValue();
        }
    }
}