package com.example.shringarmandir;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class userDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "user";
    private static final String TABLE_NAME = "credentials";
    private static final int VERSION = 1;
    private Context context;


    public userDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        try{
            sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_NAME+"(userid INTEGER primary key autoincrement, userName varchar(30)," +
                    " emailId verchar(40), password varchar(30))");
        }
        catch (Exception e){
            Toast.makeText(context,""+e,Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        try{
            Toast.makeText(context,"Dropping the existing table",Toast.LENGTH_SHORT).show();
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        }
        catch (Exception e){
            Toast.makeText(context,""+e,Toast.LENGTH_SHORT).show();
            onCreate(sqLiteDatabase);
        }
    }

    public void addUser(String name, String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues user = new ContentValues();
        user.put("userName",name);
        user.put("emailId",email);
        user.put("password",password);
        db.insert(TABLE_NAME,null,user);
        db.close();
    }

    public boolean validUser(String s){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from "+TABLE_NAME+" where emailId = '"+s+"'",null);
        String email = "";
        if(cursor.moveToFirst()){
            do {
                email = cursor.getString(2);
            }while (cursor.moveToNext());
        }
        if(email.equals(""))
            return false;
        return true;
    }

    public String getPassword(String s){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from "+TABLE_NAME+" where emailId = '"+s+"'",null);
        String pass = "";
        if(cursor.moveToFirst()){
            do {
                pass = cursor.getString(3);
            }while (cursor.moveToNext());
        }
        return pass;
    }
}
