package com.example.shringarmandir;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class pending_adapter extends RecyclerView.Adapter<pending_adapter.viewHolder> {

    ArrayList<String> order_list;
    ArrayList<ArrayList<String>> items;
    String loginType;
    Context context;

    public pending_adapter(ArrayList<String> order_list, ArrayList<ArrayList<String>> items, String loginType) {
        this.order_list = order_list;
        this.items = items;
        this.loginType = loginType;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pending_layout,parent,false);
        context = parent.getContext();
        return new viewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, final int position) {
        holder.order_id.setText(order_list.get(position));
        ArrayAdapter ad = new ArrayAdapter(context,android.R.layout.simple_spinner_dropdown_item,items.get(position));
        holder.spinner.setAdapter(ad);

        if(loginType.equals("customer"))
            holder.packed.setVisibility(View.INVISIBLE);
        holder.packed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,"Order Packed",Toast.LENGTH_SHORT).show();
                String name = order_list.get(position);
                add_data_to_packed(position,name);
                delete_data(position);

            }

        });

    }

    @Override
    public int getItemCount() {
        return order_list.size();
    }

    class viewHolder extends RecyclerView.ViewHolder {
        TextView order_id;
        Spinner spinner;
        Button packed;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            spinner = itemView.findViewById(R.id.spinner);
            order_id = itemView.findViewById(R.id.order_id);
            packed = itemView.findViewById(R.id.packed);
        }
    }

    public void add_data_to_packed(final int position, final String name){
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        ref.child("placed_orders").child(name).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ref.child("packed_orders").child(name).setValue(snapshot.getValue());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void delete_data(int position){
        order_list.remove(position);
        items.remove(position);
        notifyDataSetChanged();
    }

}
