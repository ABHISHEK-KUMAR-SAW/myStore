package com.example.shringarmandir;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class place_order_adapter extends FirebaseRecyclerAdapter<item_variables,place_order_adapter.viewHolder> {

    Context context;
    public place_order_adapter(@NonNull FirebaseRecyclerOptions<item_variables> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull viewHolder holder, int position, @NonNull final item_variables model) {
        holder.name.setText(model.getName());
        holder.price.setText(model.getPrice());
        holder.image.setImageResource(R.drawable.account_img);

        holder.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,"Item Added to cart",Toast.LENGTH_SHORT).show();
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference reference = database.getReference("orders");
                String name = model.getName();
                String price = model.getPrice();
                Map<String,Object> map= new HashMap<>();
                map.put("name",name);
                map.put("price",price);
                reference.push().setValue(map);
            }
        });
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_order_layout,parent,false);
        context = parent.getContext();
        return new viewHolder(view);
    }

    class viewHolder extends RecyclerView.ViewHolder{

        TextView name, price;
        ImageView image;
        ImageButton add;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.itemImage);
            name = itemView.findViewById(R.id.itemName);
            price = itemView.findViewById(R.id.itemPrice);
            add = itemView.findViewById(R.id.add);
        }
    }
}
