package com.example.shringarmandir;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class register extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5,e6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        e1=findViewById(R.id.first);
        e2=findViewById(R.id.last);
        e3=findViewById(R.id.email);
        e4=findViewById(R.id.password);
        e5=findViewById(R.id.confirm);
        e6=findViewById(R.id.contact);
    }

    public boolean valid(String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "(?=.*[A-Z])(?=.*[@#$%^&+=!]).*$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }

    public void register(View v)
    {
        String first = e1.getText().toString();
        String last = e2.getText().toString();
        String email = e3.getText().toString();
        String password = e4.getText().toString();
        String confirm = e5.getText().toString();
        String contact = e6.getText().toString();

        String email_match= "[A-Za-z0-9,.-_]+@[a-z]+.[a-z]+";

        if(first.isEmpty())
        {
            e1.setError("Required");
            String s = "Please Enter your First Name";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }

        else if(email.isEmpty())
        {
            e3.setError("Required");
            String s = "Please Enter your Email";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }
        else if(!email.trim().matches(email_match))
        {
            e3.setError("invalid");
            String s = "Please Enter a valid email";
            Snackbar.make(v,s,Snackbar.LENGTH_LONG).show();
        }
        else if(password.isEmpty())
        {
            e4.setError("Required");
            String s = "Please Enter your Password";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }
        else if(confirm.isEmpty())
        {
            e5.setError("Required");
            String s = "Please confirm your Password";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }
        else if(contact.isEmpty())
        {
            e6.setError("Required");
            String s = "Please Enter your Contact No.";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }

        else if(password.length()<6)
        {
            e4.setError("invalid");
            String s = "Your password should contain minimum 8 characters";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }
        else if(!password.equals(confirm))
        {
            e5.setError("do not match");
            String s = "Passwords do not match";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }
        else if(!valid(password))
        {
            e4.setError("invalid");
            String s = "Your password must contain one special character and one capital letter";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }
        else if(contact.length()!=10)
        {
            e6.setError("invalid");
            String s = "Please enter a valid contact number";
            Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this,"Your are registered successfully!!!",Toast.LENGTH_LONG).show();
            userDatabase db = new userDatabase(getApplicationContext());
            db.addUser(first+" "+last,email,password);
            Intent i = new Intent(this,login_as.class);
            startActivity(i);
        }
    }
}
