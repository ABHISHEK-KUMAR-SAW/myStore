package com.example.shringarmandir;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class completed_adapter extends RecyclerView.Adapter<completed_adapter.viewHolder>{
    ArrayList<String> order_list;
    ArrayList<ArrayList<String>> items;
    Context context;

    public completed_adapter(ArrayList<String> order_list, ArrayList<ArrayList<String>> items) {
        this.order_list = order_list;
        this.items = items;
    }

    @NonNull
    @Override
    public completed_adapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pending_layout,parent,false);
        context = parent.getContext();
        return new completed_adapter.viewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull completed_adapter.viewHolder holder, final int position) {
        holder.order_id.setText(order_list.get(position));
        ArrayAdapter ad = new ArrayAdapter(context,android.R.layout.simple_spinner_dropdown_item,items.get(position));
        holder.spinner.setAdapter(ad);
        holder.completed.setVisibility(View.INVISIBLE);
    }

    @Override
    public int getItemCount() {
        return order_list.size();
    }

    class viewHolder extends RecyclerView.ViewHolder {
        TextView order_id;
        Spinner spinner;
        Button completed;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            spinner = itemView.findViewById(R.id.spinner);
            order_id = itemView.findViewById(R.id.order_id);
            completed = itemView.findViewById(R.id.packed);
        }
    }

}
